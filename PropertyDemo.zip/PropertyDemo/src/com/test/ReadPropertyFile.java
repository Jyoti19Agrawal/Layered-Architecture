package com.test;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertyFile {

	public static void main(String[] args) {
		 Properties prop=new Properties();
		 try {
			FileReader fr=new FileReader("login.properties");
			 prop.load(fr);
			 String user=prop.getProperty("Username");
			 String pass=prop.getProperty("Userpass");
			 String email=prop.getProperty("Useremail");
			 
			 System.out.println("UserName : "+user);
			 System.out.println("UserPass : "+pass);
			 System.out.println("UserEmail : "+email);
			 prop.setProperty("Usermob", "987465321");
			 //to copy properties of one file into another use store method instead of save because it is depricated.
			 //save internally calls store method and store has two type of behaviour.
			 FileOutputStream fout=new FileOutputStream("test.properties");
			 prop.store(fout, "Added key value pair");
			 prop.list(System.out);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
 

}
