package com.test;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class TestSerial1 {

	public static void main(String[] args) {
		
		Employee obj= new Employee(1001,"Shyam", 785000);
		 try {
			FileInputStream fin=new FileInputStream("emp.dat");
			 ObjectInputStream oin=new ObjectInputStream(fin);
			 Employee em=(Employee)oin.readObject();
			 System.out.println(em.getEmpId()+" "+em.getEmpName()+" "+em.getEmpSalary());
			 oin.close();
		}  
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
