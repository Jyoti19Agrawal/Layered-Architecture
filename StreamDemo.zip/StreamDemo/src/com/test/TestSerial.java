package com.test;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestSerial {

	public static void main(String[] args) {
		Employee obj= new Employee(1001,"Shyam", 785000);
		try
		{
		
	 FileOutputStream fout= new FileOutputStream("emp.dat");
	 ObjectOutputStream out= new ObjectOutputStream(fout);
	 out.writeObject(obj);
	 out.close();
	 System.out.println("OBJECT SERIALIZED");
	 
	
		}
		catch (Exception e){
		e.printStackTrace();
		}
		}

	}


