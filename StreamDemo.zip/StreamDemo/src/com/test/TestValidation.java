package com.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestValidation {

	public static void main(String[] args) {
		int roll=120;
		
		String input = "Jyoti";
		String s1="123456789";
		//to convert primitive to string.
		String string=String.valueOf(roll+"10");
		System.out.println(string);

		// to get pattern object in java there is a class called pattern
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,6}");
		Matcher matcher= pattern.matcher(input);
		System.out.println(matcher.matches());
		
		Pattern pattern1= Pattern.compile("[0-9]{9}");
		Matcher matcher1= pattern.matcher(s1);
		System.out.println(matcher1.matches());
		
		
	}

}
