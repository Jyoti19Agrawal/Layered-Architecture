package com.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestFile {

	public static void main(String[] args) {
		try {
			FileInputStream fileInput = new FileInputStream("sample.txt");
			FileOutputStream fileOutput=new FileOutputStream("sample1.txt");
			int n = 0;
			while ((n = fileInput.read()) > 0) {
				fileOutput.write(n);
				//char ch = (char) n;
				//System.out.println(ch);
			}
			System.out.println("Copied Successfully.");
			fileInput.close();
			fileOutput.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");

		}

		catch (IOException e) {
			System.out.println("Unable to Read");

		}

	}

}
