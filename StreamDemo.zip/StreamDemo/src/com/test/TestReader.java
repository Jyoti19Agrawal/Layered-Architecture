package com.test;

import java.io.File;

public class TestReader {

	public static void main(String[] args) {
		 //to find out length of the sample.txt
		
		//String str="sample.txt";
		String str="c:/windows";
		
		//file holds a file name but you can not read and write from file.it can find length.
		// IT DOES NOT THROW ANY EXCEPTION.
		
		File file =new File(str);
		if(file.exists() && file.isDirectory())
		{
			String [] listOfFiles=file.list();
			//System.out.println("Length = "+file.length());
			//System.out.println("IS A DIRECTORY");
			
			for(String fileName : listOfFiles)
			{
			System.out.println(fileName);
			}
			
		}
		else
		{
			System.out.println("NOT A ORDINARY FILE");
			//System.out.println("file not found");
		}

	}

}
