package com.eds.test;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import com.eds.exception.EmpDetailException;
import com.eds.util.DBConnection;
public class TestConnection {

	@Test
	public void testConnection() throws EmpDetailException
	{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
		System.out.println("Connected Successfully");
		
	}
	@Ignore
	@Test(expected= EmpDetailException.class)
	public void testConnectionFail() throws EmpDetailException
	{
		Connection con=DBConnection.getConnection();
		 //agr hmare connection m kch galt hoga tbhi ye pass hoga i mean exception throw krega isliye passs
		System.out.println("Connection Fail");
	}
}


