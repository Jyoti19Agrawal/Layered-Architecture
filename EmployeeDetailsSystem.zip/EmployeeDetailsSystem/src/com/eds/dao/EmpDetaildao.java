package com.eds.dao;

import com.eds.bean.EmpDetailBean;
import com.eds.exception.EmpDetailException;

public interface EmpDetaildao {
	
	public int addEmployee(EmpDetailBean bean) throws EmpDetailException;
	public EmpDetailBean viewEmployeeById (int id) throws EmpDetailException;
}
