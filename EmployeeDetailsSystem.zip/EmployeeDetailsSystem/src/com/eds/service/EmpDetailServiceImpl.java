package com.eds.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.eds.bean.EmpDetailBean;
import com.eds.dao.EmpDetailDaoImpl;
import com.eds.dao.EmpDetaildao;
import com.eds.exception.EmpDetailException;

public class EmpDetailServiceImpl implements EmpDetailService{
	private EmpDetaildao employeeDao = new EmpDetailDaoImpl();


	@Override
	public int addEmployee(EmpDetailBean bean) throws EmpDetailException {
		int id = employeeDao.addEmployee(bean);
		return id;
	}

	@Override
	public EmpDetailBean viewEmployeeById(int empid) throws EmpDetailException {
		EmpDetailBean bean = new EmpDetailBean();
		bean = employeeDao.viewEmployeeById(empid);
		return bean;
	}
	
	public boolean validateEmployee(EmpDetailBean bean) throws EmpDetailException
	{
		boolean validate=false;
		List<String> validationErrors = new ArrayList<String>();

	 
		if(!(isValidfName(bean.getEmp_fname()))) 
		{
			validationErrors.add("\n Donar first Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		 
		if(!(isValidlName(bean.getEmp_lname())))
		{
			validationErrors.add("\n Donar last Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		 
		if(!(isValidPhoneNumber(bean.getEmp_contact())))
		{
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		 
		if(!(isValideName(bean.getEmp_email())))
		{
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new EmpDetailException(validationErrors +"");
		else
		{
			validate = true;
		}
		return validate;
	}

	public boolean isValidfName(String name){
		Pattern namePattern=Pattern.compile("^[A-Z][A-Za-z]{3,14}$");
		Matcher nameMatcher=namePattern.matcher(name);
		return nameMatcher.matches();
	}
	 

	public boolean isValidlName(String name){
		Pattern namePattern=Pattern.compile("^[A-Z][A-Za-z]{3,14}$");
		Matcher nameMatcher=namePattern.matcher(name);
		return nameMatcher.matches();
	}
	 
	 
	
	public boolean isValidPhoneNumber(CharSequence l){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(l);
		return phoneMatcher.matches();
		
	}
	
	public boolean isValideName(String lname){
		Pattern namePattern=Pattern.compile("^[a-z0-9.%_+-]+@[a-z]+\\.[a-z]{2,6}$");
		Matcher nameMatcher=namePattern.matcher(lname);
		return nameMatcher.matches();
	}

	 
	 	
	

}
