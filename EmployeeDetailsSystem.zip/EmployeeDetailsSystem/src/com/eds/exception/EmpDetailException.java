package com.eds.exception;

public class EmpDetailException extends Exception{
	
	public EmpDetailException (String msg)
	{
		super(msg);
	}

}
