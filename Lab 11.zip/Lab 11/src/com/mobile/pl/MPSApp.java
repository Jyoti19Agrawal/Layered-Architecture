package com.mobile.pl;

import java.util.Scanner;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.service.MobileService;
import com.mobile.service.MobileServiceImpl;
public class MPSApp {

	public static void main(String[] args) {
		MobileService service = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		int ch;

		do {
			System.out
					.println("1.Insert Mobile ID.\n");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Mobile Name = ");
				String name = sc.next();
				System.out.println("Enter Employee Price = ");
				int price = sc.nextInt();

				MobileBean bean = new MobileBean();
				bean.setName(name); 
				bean.setPrice(price); 
				try {
					int id = service.addPurchaseDetails(bean);
					System.out.println("MobileId Added Successfully= " + id);
				} catch (MobileException e) {
					System.out.println("MobileID cannot Added.");

				}
				break;
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			ch = sc.nextInt();
		} while (ch != 2);
		System.out.println("ThankYou! Welcome back Again.");

	}
		}
		
