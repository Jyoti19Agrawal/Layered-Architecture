package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.mobile.bean.MobileBean;
import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class MobileDaoImpl implements MobileDao {

	public int mobileId() {
		int id = 0;
		Connection con = null;
		String myquery = "select purchaseid_sequence.nextval from dual";
	try {
		con = DBConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rst = stmt.executeQuery(myquery);
		rst.next();// to move cursor
		id = rst.getInt(1);// here 1 is the column 1 means id column
	} catch (Exception e) {
			e.printStackTrace();
	}
	return id;
	}
	@Override
	public int addPurchaseDetails(MobileBean bean) throws MobileException {
		Connection con = null;
		int id = 0;
		String cmd = "insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values (?,?,?,?,?,?)";
		try {
			con = DBConnection.getConnection();
			id = mobileId();
			PreparedStatement pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getCname());
			pstmt.setString(3, bean.getMailid());
			pstmt.setString(4, bean.getPhoneno());
			LocalDate today=LocalDate.now();
			pstmt.
			int n = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new MobileException("Unable to insert");
}
		return id;
		 
		
	}

}
