package com.mobile.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.mobile.exception.MobileException;

public class DBConnection {
	
	 
		
	
	public static Connection getConnection() throws MobileException
	{
		Connection con=null;
		//since this file can be viewed by many people so make one property file and store it there.
		Properties prop =new Properties();
		try {
			FileReader fr=new FileReader("resources/jdbc.properties");
			prop.load(fr);
			String url=prop.getProperty("jdbcurl");
			String user=prop.getProperty("jdbcuser");
			String pass=prop.getProperty("jdbcpass");
			con= DriverManager.getConnection(url,user,pass);
			System.out.println("Connected");
		} catch (FileNotFoundException e) {
			 throw  new MobileException("jdbc.properties file not found");
			 
		} catch (IOException e) {
			 throw new MobileException("Unable to read properties file");
		} catch (SQLException e) {
			 throw new MobileException("Unable to connect to database");
		}
		
		return(con);
		
		
	}
	 
	
}
