package com.calc;

public class calculator {
	public int add(int num1, int num2)
	{
		return (num1+num2);
	}
	public int sub(int num1,int num2)
	{
		return(num1-num2);
	}
	public int divide(int num1, int num2)throws IllegalArgumentException
	{
		if(num2==0)
		{
			throw new IllegalArgumentException("Denominator should not be zero");
		}
		
		return (num1/num2);
	}
}
