package com.calc.test;
//to import all the method of that particular class
import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.calc.calculator;

public class CalculatorTestCase {
	static calculator cal;
	
	//1 bar call krne k liye method bna do 
	@BeforeClass
	public static void beforeTest()
	{
		  cal=new calculator();
	}
	
	@Test
	public void testAdd()
	{
		//calculator cal=new calculator();
		int n=cal.add(10, 20);
		assertEquals(30, n);
	}
	
	@Test
	public void testSub()
	{
		//calculator cal=new calculator();
		int n=cal.sub(10,5);
		assertEquals("Testing 10 and 5",5, n);// to exactly know the error give a message.
	}
	@Test
	public void testDivide()
	{
		//calculator cal=new calculator();
		int n=cal.divide(10, 5);
		assertEquals("testing of numbers:" , 2, n);
	}

	@Test(expected=IllegalArgumentException.class)
	public void testDivideCase()
	{
		//calculator cal=new calculator();
		int n=cal.divide(20, 0);
		//assertEquals("testing of numbers:" , 2, n);//it will not come now
	}
}
