package com.emp.pl;

import java.util.List;
import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import comp.emp.service.EmployeeService;
import comp.emp.service.EmployeeServiceImpl;

public class EMSApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ch;

	do {
			System.out
					.println("1.Insert employee.\n2.Delete Employee by Id\n3.View Employee\n4.View Employee By Id");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Employee Name = ");
				String name = sc.next();
				System.out.println("Enter Employee salary = ");
				int salary = sc.nextInt();

				EmployeeBean bean = new EmployeeBean();
				bean.setEmpname(name);
				bean.setEmpsalary(salary);

				EmployeeService service = new EmployeeServiceImpl();
				try {
					int id = service.addEmployee(bean);
					System.out.println("Employee Added success ID= " + id);
				} catch (EmployeeException e) {
					System.out.println(e);

				}
				break;

			case 2:

				System.out.println("Enter employee ID: ");
				int empid = sc.nextInt();
				EmployeeService service1 = new EmployeeServiceImpl();
				try {
					int id = service1.deleteEmployeeById(empid);
					System.out.println("Employee ID deleted successfully\n "
							+ id);
				} catch (EmployeeException e) {
					System.out.println(e);
				}
				break;

			case 3:
				EmployeeService service2 = new EmployeeServiceImpl();
				List<EmployeeBean> list = null;
				try {
					list = service2.viewAllEmployee();
					 for(EmployeeBean bean1 : list)
					 {
						 System.out.println(bean1.toString());
					 }

				} catch (EmployeeException e) {

					System.out.println("Error : " + e.getMessage());
				}
				 break;
				 
			case 4:
				System.out.println("Enter employee ID: ");
				int empid1 = sc.nextInt();
				EmployeeService service3 = new EmployeeServiceImpl();
				try {
					EmployeeBean bean2 = service3.viewEmployeeById(empid1);
					System.out.println("Employee Details : \n"+ bean2);
				} catch (EmployeeException e) {
					System.out.println("No Record found");
				}
				break;
				default :
				{
					System.out.println("Invalid Choice");
				}
				
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			ch = sc.nextInt();
		} while (ch != 2);
		System.out.println("ThankYou! Welcome back Again.");

	}

}
