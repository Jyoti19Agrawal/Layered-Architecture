package com.emp.pl;

import java.util.Scanner;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

import comp.emp.service.EmployeeService;
import comp.emp.service.EmployeeServiceImpl;

public class EMSApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int ch;
		
		
		do
		{
			System.out.println("1.Insert employee.\n2.Delete Employee\n3.View Employee");
			System.out.println("Enter your choice: ");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter Employee Name = ");
				String name=sc.next();
				System.out.println("Enter Employee salary = ");
				int salary = sc.nextInt();
				
				EmployeeBean bean=new EmployeeBean();
				bean.setEmpname(name);
				bean.setEmpsalary(salary);
				
				
				EmployeeService service = new EmployeeServiceImpl();
				try {
					int id = service.addEmployee(bean);
					System.out.println("Employee Added success ID= "+id);
				} catch (EmployeeException e) {
					 System.out.println(e);
					 
				}
				break;
				
			case 2:
				
				System.out.println("Enter employee ID: ");
				int empid=sc.nextInt();
				EmployeeService service1 = new EmployeeServiceImpl();
				  try {
						int id=service1.deleteEmployeeById(empid);
						System.out.println("Employee ID deleted successfully\n "+id);
					} catch (EmployeeException e) {
						 System.out.println(e);
					}
				break;
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			 ch=sc.nextInt();
		}while(ch!=2);
		System.out.println("ThankYou! Welcome back Again.");
		
		
		
		
		 
		
		
	             
	}

}
