package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {
	
	Logger logger=Logger.getLogger(EmployeeDaoImpl.class);
	 public EmployeeDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	

	@Override
	public int deleteEmployeeById(int id) throws EmployeeException {

		Connection con = null;
		Statement stmt;
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "delete from emp_tbl where empid=" + id;
			ResultSet result = stmt.executeQuery(cmd);
		} catch (SQLException e) {
			System.out.println(e);

		}

		return id;
	}

	public int generateEmployeeId() {
		int id = 0;
		Connection con = null;
		String myquery = "select empid_sequence.nextval from dual";
		/*
		 * Connection con= DBConnection.getConnection();
		 * 
		 * String myquery = "select empid_sequence.nextval from dual"; try {
		 * 
		 * Statement stmt=con.createStatement(); ResultSet
		 * rst=stmt.executeQuery(myquery); rst.next();// to move cursor
		 * id=rst.getInt(1);// here 1 is the column 1 means id column } catch
		 * (SQLException e) {
		 * 
		 * e.printStackTrace(); } return id;
		 */

		// qki hm propertyfile use kiye h isliye ye exception dega to change kro
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(myquery);
			rst.next();// to move cursor
			id = rst.getInt(1);// here 1 is the column 1 means id column
		} catch (Exception e) {

			e.printStackTrace();
		}
		return id;

	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		logger.debug("Add Employee called form Dao layer");
		logger.info("Add employee called");
		Connection con = null;
		int id = 0;
		String cmd = "insert into emp_tbl(empid,empname,empsalary) values (?,?,?)";
		try {
			con = DBConnection.getConnection();
			id = generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpname());
			pstmt.setInt(3, bean.getEmpsalary());
			int n = pstmt.executeUpdate();
			logger.debug("Insert success");
		} catch (SQLException e) {
			logger.error("Exception in add employee method"+e);
			throw new EmployeeException("Unable to insert");

		}
		return id;
	}

	@Override
	public List<EmployeeBean> viewAllEmployee() throws EmployeeException {
		Connection con = null;
		Statement stmt;
		List<EmployeeBean> employeeList = new ArrayList<EmployeeBean>();
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select empid, empname, empsalary from emp_tbl";
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				EmployeeBean bean = new EmployeeBean();
				bean.setEmpid(resultset.getInt(1));
				bean.setEmpname(resultset.getString(2));
				bean.setEmpsalary(resultset.getInt(3));

				employeeList.add(bean);

			}
		} catch (SQLException e) {
			System.out.println(e);

		}
		return employeeList;

	}

	@Override
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException {
		Connection con = null;

		ResultSet resultset = null;
		PreparedStatement preparedStatement = null;
		EmployeeBean bean = new EmployeeBean();
		try {
			con = DBConnection.getConnection();

			String cmd = "select empid,empname,empsalary from emp_tbl where empid="
					+ id;
			preparedStatement = con.prepareStatement(cmd);
			resultset = preparedStatement.executeQuery();

			if (resultset.next()) {
				bean.setEmpid(resultset.getInt(1));
				bean.setEmpname(resultset.getString(2));
				bean.setEmpsalary(resultset.getInt(3));
			}
		} catch (SQLException e) {
			System.out.println(e);

		}

		return bean;

	}
}