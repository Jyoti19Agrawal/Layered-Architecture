package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.annotation.Generated;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {

	 
	

	@Override
	public int deleteEmployeeById(int id) throws EmployeeException {
		
		Connection con= DBConnection.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			String cmd="delete from emp_tbl where empid="+id;
			ResultSet result=stmt.executeQuery(cmd);
		} catch (SQLException e) {
			 System.out.println(e);
			 
		}
		
		 
		return id;
	}
	public int generateEmployeeId()
	{
		int id=0;
		Connection con= DBConnection.getConnection();
		String myquery = "select empid_sequence.nextval from dual";
		try {
			Statement stmt=con.createStatement();
			ResultSet rst=stmt.executeQuery(myquery);
			rst.next();// to move cursor
			id=rst.getInt(1);// here 1 is the column 1 means id column
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con = DBConnection.getConnection();
		int id=0;
		String cmd = "insert into emp_tbl(empid,empname,empsalary) values (?,?,?)";
		try {
			id=generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpname());
			pstmt.setInt(3, bean.getEmpsalary());
			int n = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");

		}
		return id;
	}
	@Override
	public List<EmployeeBean> viewllEmployee()throws EmployeeException{
		Connection con= DBConnection.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			String cmd="select empid, empname, empsalary from emp_tbl" ;
			ResultSet result=stmt.executeQuery(cmd);
			if(result.next()){
				int id=result.getInt(1);
				
				//result.next();
				String name=result.getString(2);
				//result.next();
				int sal=result.getInt(3);
				
			}
			List<String> nlist=getAllElements(list);
		} catch (SQLException e) {
			 System.out.println(e);
		return ;
	}
	
	
}
