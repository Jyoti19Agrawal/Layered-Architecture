package comp.emp.service;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
	public int deleteEmployeeById(int empid) throws EmployeeException;
	
		
	
}
