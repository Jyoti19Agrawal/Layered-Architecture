package comp.emp.service;

import java.util.List;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
	public int deleteEmployeeById(int empid) throws EmployeeException;
	public List<EmployeeBean>viewAllEmployee() throws EmployeeException;
	
	public EmployeeBean viewEmployeeById(int empid) throws EmployeeException;
	
		
	
}
