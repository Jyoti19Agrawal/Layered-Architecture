package com.ems.dao.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeBean;
import com.emp.dao.EmployeeDaoImpl;
import com.emp.exception.EmployeeException;

public class TestDaoImpl {
	static EmployeeDaoImpl employeeDao;
	static EmployeeBean empBean;
	@BeforeClass
	public static void beforeClass()
	{
		employeeDao=new EmployeeDaoImpl();
		empBean=new EmployeeBean();
	}
	@Test
	public void testAddEmployee() throws EmployeeException
	{
		empBean.setEmpname("Jyoti");
		empBean.setEmpsalary(500000);
		int id=employeeDao.addEmployee(empBean);
		 assertTrue(id>0);
	}
}
