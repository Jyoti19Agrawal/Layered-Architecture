
package com.ems.dao.test;

import java.sql.Connection;

import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.*;

import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class TestForConnection {
	@Ignore
	@Test
	public void testConnection() throws EmployeeException
	{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
		
	}
	
	@Test(expected= EmployeeException.class)
	public void testConnectionFail() throws EmployeeException
	{
		Connection con=DBConnection.getConnection();
		 //agr hmare connection m kch galt hoga tbhi ye pass hoga i mean exception throw krega isliye passs
	}
}
